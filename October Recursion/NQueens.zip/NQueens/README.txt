This archive has been reorganized by Daniel Johnson (johnmon2@gmail.com).  The reorganization was done to enable the files to compile without worrying about making the given libraries work.

List of changes:
1. The Following files were moved out of the JavaSourceFiles folder into the NQueens folder: NQueensLab.java, NQueens.java, Queen.java.
2. The empty JavaSourceFiles folder was deleted.
3. The grid.jar file was extracted into the NQueens folder (appears as the edu folder).
4. This README file was created.
